import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  debugShowCheckedModeBanner: false,
  home: MyApp(),
));

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ESTER ANGGRAINI ",
          style: new TextStyle(
              fontSize: 24.0, fontWeight: FontWeight.bold
          ),),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      //backgroundColor: Colors.blue[100],
      body:
      GridView.count(
        primary: false,
        padding: const EdgeInsets.all(20),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        crossAxisCount: 3,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text("Ester 1"),
            color: Colors.red[100],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Ester 2'),
            color: Colors.red[200],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text("Ester 3"),
            color: Colors.red[100],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text("Ester 4"),
            color: Colors.red[100],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text("Ester 5"),
            color: Colors.red[100],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Ester 6'),
            color: Colors.red[300],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Ester 7'),
            color: Colors.red[400],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Ester 8'),
            color: Colors.red[500],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            child: const Text('Ester 9'),
            color: Colors.red[600],
          ),
        ],
      ),
    );  }
}